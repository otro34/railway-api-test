# the-one-with-the-express-sequelize-api
Sample project for an API using express and sequelize
